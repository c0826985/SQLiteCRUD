package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView Header,HeightText,WeightText,Category;
    EditText HeightInput,WeightInput;
    Button Submit;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        HeightInput = findViewById(R.id.HeightInput);
        WeightInput = findViewById(R.id.WeightInput);

        Category = findViewById(R.id.Category);
        Submit = findViewById(R.id.Submit);

        Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(HeightInput.getText().toString().isEmpty())
                    Toast.makeText(getBaseContext(), "Please Enter Height",Toast.LENGTH_LONG).show();
                else if(WeightInput.getText().toString().isEmpty())
                    Toast.makeText(getBaseContext(), "Please Enter Weight",Toast.LENGTH_LONG).show();
        else{
            double Height = Double.parseDouble(HeightInput.getText().toString());
                    double Weight = Double.parseDouble(WeightInput.getText().toString());
                    double BMI = Weight / (0.01 * 0.01 * (Height * Height));
                    if(BMI >= 30)
                        Category.setText("Obesity");
                    if(BMI > 25 && BMI < 30)
                        Category.setText("Over Weight");
                    if(BMI >= 18.5 && BMI < 25)
                        Category.setText("Normal Weight");
                    if(BMI < 18.5)
                        Category.setText("Under Weight");


                }


            }
        });


    }
}